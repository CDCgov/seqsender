from .custom_component import custom_component

__all__ = [
    "custom_component",
]
