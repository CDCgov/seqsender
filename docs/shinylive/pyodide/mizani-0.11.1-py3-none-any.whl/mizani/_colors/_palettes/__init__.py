from ._palette import palette

__all__ = ("palette",)
