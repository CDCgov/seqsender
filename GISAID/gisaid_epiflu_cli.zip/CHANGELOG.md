**v1.0.1**

Added date parser to correct input date format anomalies. User can now
    select input date format.

**v1.0.0**

Beta version.
epiflu_cli upload features:
    authenticate
    upload
    template and --template
    version
    labs
