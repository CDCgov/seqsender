from cli3 import __version__
__st__ = __version__

