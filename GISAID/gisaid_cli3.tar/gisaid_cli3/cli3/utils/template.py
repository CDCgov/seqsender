#!/usr/bin/env python3

TEMPLATE = """submitter,covv_virus_name,covv_type,covv_passage,covv_collection_date,covv_location,covv_add_location,covv_host,covv_add_host_info,covv_sampling_strategy,covv_gender,covv_patient_age,covv_patient_status,covv_specimen,covv_outbreak,covv_last_vaccinated,covv_treatment,covv_seq_technology,covv_assembly_method,covv_coverage,covv_orig_lab,covv_orig_lab_addr,covv_provider_sample_id,covv_subm_lab,covv_subm_lab_addr,covv_subm_sample_id,covv_authors
,,betacoronavirus,,,,,,,,,,,,,,,,,,,,,,,,
,,betacoronavirus,,,,,,,,,,,,,,,,,,,,,,,,
,,betacoronavirus,,,,,,,,,,,,,,,,,,,,,,,,
,,betacoronavirus,,,,,,,,,,,,,,,,,,,,,,,,
,,betacoronavirus,,,,,,,,,,,,,,,,,,,,,,,,
,,betacoronavirus,,,,,,,,,,,,,,,,,,,,,,,,
,,betacoronavirus,,,,,,,,,,,,,,,,,,,,,,,,
,,betacoronavirus,,,,,,,,,,,,,,,,,,,,,,,,
,,betacoronavirus,,,,,,,,,,,,,,,,,,,,,,,,
"""