SEQUENCERS = """BRAND,MODEL
BioZ,BioelectronSeq 4000
ClearLabs,Clear Labs Dx
Illumina,HiSeq 1500
Illumina,HiSeq 2500
Illumina,HiSeq 3000
Illumina,HiSeq 4000
Illumina,HiSeq X
Illumina,iSeq 100
Illumina,MiniSeq
Illumina,MiSeq
Illumina,NextSeq 2000
Illumina,NextSeq 500
Illumina,NextSeq 550
Illumina,NextSeq 550 Dx
Illumina,NovaSeq 6000
MGI,DNBSEQ BGISEQ-500
MGI,DNBSEQ G400
MGI,DNBSEQ G400RS
MGI,DNBSEQ G50
MGI,DNBSEQ T7
Oxford Nanopore Technologies,GridION
Oxford Nanopore Technologies,MinION
Oxford Nanopore Technologies,PromethION
PacBio,Sequel I
PacBio,Sequel II
Thermo Fisher,AB 3500
Thermo Fisher,AB 3500 Dx
Thermo Fisher,AB 3730
Thermo Fisher,AB 3730XL
Thermo Fisher,Ion Torrent
Thermo Fisher,Genexus
Thermo Fisher,Ion PGM Dx
Thermo Fisher,Ion Proton
Thermo Fisher,Ion GeneStudio S5
Thermo Fisher,Ion GeneStudio S5 XL"""